const axios = require('axios')
const AWS = require('aws-sdk')
const { JSDOM } = require('jsdom')
const dynamodb = new AWS.DynamoDB.DocumentClient()
const S3 = new AWS.S3()
require('dotenv').config()

const WAAPI_API_KEY = process.env.WAAPI_API_KEY
const WAAPI_INSTANCE_ID = process.env.WAAPI_INSTANCE_ID
const BUCKET_NAME = process.env.BUCKET_NAME
const MONGODB_URI = process.env.MONGODB_URI
const MELTWATER_ACCOUNT_ID = process.env.MELTWATER_ACCOUNT_ID

const { MongoClient, ServerApiVersion } = require('mongodb')
const uri = MONGODB_URI

// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  },
})

const oneMonthInSeconds = 30 * 24 * 60 * 60 // 30 days in seconds
const expirationTime = Math.floor(Date.now() / 1000) + oneMonthInSeconds

exports.handler = async (event) => {
  proceso()

  //await extractHtmlContent(idEnvio)
  //await sendWhatsapp(destinatarios, idEnvio, subject)
}

const compareFiles = async (mwId) => {
  try {
    // Fetch HTML file from URL
    const response = await axios.get(
      `https://app.meltwater.com/api/public/newsletters/${MELTWATER_ACCOUNT_ID}/newsletter/distribution/${mwId}/html`
    )
    const htmlContent = response.data
    // Fetch file from S3
    const params = {
      Bucket: BUCKET_NAME,
      Key: `/informesmw/${mwId}.html`,
    }

    const s3FileExists = await S3.headObject(params).promise()
    console.log(s3FileExists)
    return

    const s3Data = await S3.getObject(params).promise()
    const s3Content = s3Data.Body.toString('utf-8')

    // Compare the contents
    if (htmlContent !== s3Content) {
      console.log('yes')
    } else {
      console.log('no')
    }
  } catch (error) {
    console.error('Error comparing files:', error)
  }
}

const getClientes = async function () {
  const params = [
    {
      $match: {
        correo: {
          $regex: '@meltwater\\.com$',
        },
        borrado: false,
      },
    },
    {
      $group: {
        _id: '$clienteId',
        correo: {
          $first: '$correo',
        },
      },
    },
    {
      $lookup: {
        from: 'usuarioclientes',
        let: {
          clienteId: '$_id',
        },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  {
                    $eq: ['$clienteId', '$$clienteId'],
                  },
                  {
                    $not: [
                      {
                        $regexMatch: {
                          input: '$correo',
                          regex: '@meltwater\\.com$',
                        },
                      },
                    ],
                  },
                  {
                    $not: [
                      {
                        $regexMatch: {
                          input: '$correo',
                          regex: '@c\\.us$',
                        },
                      },
                    ],
                  },
                  {
                    $eq: ['$borrado', false],
                  },
                ],
              },
            },
          },
          {
            $project: {
              correo: 1,
            },
          },
        ],
        as: 'toEmails',
      },
    },
    {
      $project: {
        _id: 0,
        clienteId: '$_id',
        meltwaterId: '$correo',
        toEmails: 1,
      },
    },
  ]
  try {
    // Connect the client to the server	(optional starting in v4.7)
    await client.connect()
    // Send a ping to confirm a successful connection
    const collection = client.db('controles').collection('usuarioclientes')
    const result = await collection.aggregate(params).toArray()
    return result
  } finally {
    // Ensures that the client will close when you finish/error
    await client.close()
  }
}

const proceso = async function () {
  try {
    const clientes = await getClientes()

    for (const cliente of clientes) {
      const { clienteId, meltwaterId, toEmails } = cliente
      const mwId = meltwaterId.split('@')[0]
      //console.log(clienteId, mwId, toEmails)
      const sendNotification = await compareFiles(mwId)
    }
  } catch (error) {
    console.error('Error:', error)
  }
}

proceso().catch(console.dir)
