Lambda function que es llamada periódicamente por un evento de eventbridge

https://us-east-1.console.aws.amazon.com/scheduler/home?region=us-east-1#schedules/default/call-whatsapp-informes-mw
